export const colors = {
  white: "#FFFFFF",

  primary: {
    900: "#6200EE"
  }
};