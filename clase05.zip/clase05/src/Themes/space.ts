export const space = {
  xs: 4,
  s: 8,
  xl: 24,
  xxl: 40
};