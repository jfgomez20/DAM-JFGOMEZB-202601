import React from "react";
import AuthTemplate from "../../components/templates";
import { LoginForm } from "../../components/organism";
const LoginPage = () => {
    return (
        <authTemplate title="Welcome Back!" subtitle="Please login to your account">
            <LoginForm />
        </authTemplate>
    );
}

export default LoginPage;